# Website Toko Baju Modern 2026

File ini berisi template website jual beli pakaian modern 2026 yang siap diunggah ke **GitHub Pages**.

## Cara Penggunaan:
1. Ekstrak file `index.html` dari arsip ZIP ini.
2. Buat repositori baru di [GitHub](https://github.com/).
3. Unggah file `index.html` ke repositori tersebut.
4. Buka **Settings > Pages** pada repositori GitHub Anda.
5. Pilih branch `main` (atau `master`) dan klik **Save**.
6. Website Anda siap diakses secara online!
